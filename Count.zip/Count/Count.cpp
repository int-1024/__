#include <bits/stdc++.h>
using namespace std;

unordered_map <int, int> pts;
unordered_map <int, string> mp;

int main(void)
{
#ifndef Debug
	freopen("List.txt", "r", stdin);
	freopen("Finally.txt", "w", stdout);
#endif 
	for (int i = 1;i <= 53; ++i)
	{
		string x;
		cin >> x;
		cerr << i << " : " << x << '\n';
		mp[i] = x;
	}
	
	for (int i = 1;i <= 53; ++i)
	{
		int x;
		cin >> x >> x >> x;
		pts[i] = x;
	}
	
	auto number = 0;
	while (cin >> number)
	{
		int add;
		cin >> add;
		pts[number] += add;
	}
	
	for (int i = 1;i <= 53; ++i)
		cout << i << " " << mp[i] << " : " << pts[i] << '\n';
 
	return 0;
}
