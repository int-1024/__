#include <bits/stdc++.h>
#include <vector>
using namespace std;

unordered_map <string, int> classmatesList;
unordered_map <int, string> classmates;
unordered_map <int, bool> isIn;

int insert(string x)
{
	int idx = -1;
	string tmp = "";
	for (int i = 0;i < x.size(); ++i)
		for (int j = i + 1;j < x.size(); ++j)
		{
			tmp = "";
			for (int k = i;k <= j; ++k)	
				tmp += x[k];
			if (classmatesList[tmp] != 0)
			{
				cerr << tmp << '\n';
				idx = classmatesList[tmp];
				break;
			}
		}
	return idx;
}

inline int get(string x)
{
	int number = 0;
	for (auto c : x)
	{
		if (c >= '0' && c <= '9')
			number = number * 10 + c - '0';
	} return number;
}

int main(void)
{
	ios::sync_with_stdio(0), cin.tie(0);
	
#ifndef LOCAL
	freopen("classmatesList.txt", "r", stdin);
	freopen("lateClassmates.txt", "w", stdout);
#endif

	for (int i = 1;i <= 53; ++i)
	{
		string x;
		cin >> x;
		classmatesList[x] = i;
		classmates[i] = x;
	}
	
	vector <string> Input;
	vector <int> lateClassmates;
	vector <string> noName;
	string x;
	
	cin >> x;
	while (cin >> x)
		Input.push_back(x);
	
	for (auto x : Input)
	{
		int d = insert(x);
		if (d == -1)
			 noName.push_back(x);
		else
			isIn[d] = 1;
	}
	
	for (int i = 1;i <= 53; ++i)
		if (!isIn[i])
			lateClassmates.push_back(i);
			
	if (lateClassmates.size() == 0)
		cout << "ȫ��" << '\n';
	else
	{
		cout << "�ٵ���ͬѧ��\n";
		for (size_t i = 0;i < lateClassmates.size(); ++i)
			cout << lateClassmates[i] << ' ' << classmates[lateClassmates[i]] << '\n';
		cout << "���ƣ�" << lateClassmates.size() << "��\n"; 
	}
	
	if (noName.size())
	{
		cout << "\n���ֲ�����Ҫ�� \n";
		for (auto x : noName)
			cout << x << '\n';
		cout << "���� �� " << noName.size() << "��\n"; 
	}
	
	return 0;
}
